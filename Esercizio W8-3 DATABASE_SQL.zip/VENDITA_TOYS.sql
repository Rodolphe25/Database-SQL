USE vendita;

CREATE TABLE TOYS (
    toyID INT AUTO_INCREMENT PRIMARY KEY,
    toyName VARCHAR(255)
);

CREATE TABLE ProductCategory (
    ProductCategoryID INT AUTO_INCREMENT PRIMARY KEY,
    productID INT,
    toyID INT,
    ProductCategoryName VARCHAR(255),
    FOREIGN KEY (productID) REFERENCES Products(productID),
    FOREIGN KEY (toyID) REFERENCES TOYS(toyID)
);

CREATE TABLE Products (
    ProductID INT AUTO_INCREMENT PRIMARY KEY,
    ProductName VARCHAR(255),
    ProductPrice DECIMAL(10, 2),
    ProductImage VARCHAR(255),
    ProductDescription TEXT,
    ProductBrand VARCHAR(255),
    ProductQuantity INT
);

CREATE TABLE Sales (
    SalesID INT AUTO_INCREMENT PRIMARY KEY,
    ProductID INT,
    RegionID INT,
    SalesTotalPrice DECIMAL(10, 2),
    SalesDate DATE,
    SalesProductQuantity INT,
    SalesProductName VARCHAR(255),
    FOREIGN KEY (ProductID) REFERENCES Products(ProductID),
    FOREIGN KEY (RegionID) REFERENCES Regions(RegionID)
);

CREATE TABLE Region (
    RegionID INT AUTO_INCREMENT PRIMARY KEY,
    RegionName VARCHAR(255)
);


CREATE TABLE Country ( CountryID INT AUTO_INCREMENT PRIMARY KEY,
    RegionID INT,
    CountryName VARCHAR(255),
    PostalCode VARCHAR(10),
    FOREIGN KEY (RegionID) REFERENCES Region(RegionID)
);






INSERT INTO TOYS (toyID, toysName) VALUES
(1, 'Action Figure'),
(2, 'LEGO Set'),
(3, 'Barbie Doll'),
(4, 'Teddy Bear'),
(5, 'RC Car'),
(6, 'Board Game'),
(7, 'Puzzle'),
(8, 'Dollhouse'),
(9, 'Play-Doh Set'),
(10, 'Stuffed Animal');

INSERT INTO ProductCategory (ProductCategoryID, productID, toyID, ProductCategoryName) VALUES
(1, 101, 1, 'Action Figures'),
(2, 102, 2, 'LEGO Sets'),
(3, 103, 3, 'Dolls'),
(4, 104, 4, 'Stuffed Animals'),
(5, 105, 5, 'Remote Control Toys'),
(6, 106, 6, 'Board Games'),
(7, 107, 7, 'Puzzles'),
(8, 108, 8, 'Dollhouses'),
(9, 109, 9, 'Arts & Crafts'),
(10, 110, 10, 'Educational Toys');


INSERT INTO Product (ProductID, productName, ProductPrice, ProductImage, ProductDescription, ProductBrand, ProductQuantity) VALUES
(101, 'Action Figure Spider-Man', 19.99, 'spiderman_action_figure.jpg', 'Action Figure di Spider-Man con articolazioni flessibili.', 'Marvel', 50),
(102, 'LEGO Classic Set di Costruzioni', 29.99, 'lego_set.jpg', 'Set LEGO Classic con mattoncini per creare diverse costruzioni.', 'LEGO', 100),
(103, 'Barbie Fashionista', 24.99, 'barbie_fashionista.jpg', 'Bambola Barbie Fashionista con abiti e accessori alla moda.', 'Barbie', 75),
(104, 'Orso di Peluche Gigante', 39.99, 'giant_teddy_bear.jpg', 'Orso di peluche gigante morbidissimo, perfetto per abbracciare.', 'Plush Co.', 30),
(105, 'Auto Radiocomandata RC Turbo', 49.99, 'rc_turbo_car.jpg', 'Auto radiocomandata RC Turbo con funzioni avanzate di movimento.', 'TurboTech', 20),
(106, 'Monopoly Classico', 29.99, 'monopoly_board_game.jpg', 'Gioco da tavolo Monopoly classico per tutta la famiglia.', 'Hasbro', 60),
(107, 'Puzzle 1000 Pezzi - Paesaggio Montano', 14.99, 'mountain_landscape_puzzle.jpg', 'Puzzle con immagine di un bellissimo paesaggio montano.', 'PuzzleWorld', 40),
(108, 'Casa delle Bambole in Legno', 79.99, 'wooden_dollhouse.jpg', 'Casa delle bambole in legno con arredamento completo e luci funzionanti.', 'Toys Us', 15),
(109, 'Set di Pittura per Bambini', 12.99, 'kids_paint_set.jpg', 'Set completo di pitture e pennelli per bambini per stimolare la creatività.', 'ArtCraft', 80),
(110, 'Kit di Esperimenti Scientifici per Bambini', 34.99, 'science_kit.jpg', 'Kit di esperimenti scientifici per bambini per imparare giocando.', 'EduTech', 25);

INSERT INTO Sales (SalesID, productID, RegionID, SalesTotalPrice, SalesDate, SalesProductQuantity, SalesProductName) VALUES
(1, 101, 1, 39.99, '2024-02-01', 2, 'Action Figure Spider-Man'),
(2, 102, 2, 89.97, '2024-02-02', 3, 'LEGO Classic Set di Costruzioni'),
(3, 103, 3, 74.97, '2024-02-03', 3, 'Barbie Fashionista'),
(4, 104, 1, 79.98, '2024-02-04', 2, 'Orso di Peluche Gigante'),
(5, 105, 2, 99.98, '2024-02-05', 2, 'Auto Radiocomandata RC Turbo'),
(6, 106, 3, 59.97, '2024-02-06', 2, 'Monopoly Classico'),
(7, 107, 1, 29.98, '2024-02-07', 2, 'Puzzle 1000 Pezzi - Paesaggio Montano'),
(8, 108, 2, 159.98, '2024-02-08', 2, 'Casa delle Bambole in Legno'),
(9, 109, 3, 25.98, '2024-02-09', 2, 'Set di Pittura per Bambini'),
(10, 110, 1, 69.98, '2024-02-10', 2, 'Kit di Esperimenti Scientifici per Bambini');


INSERT INTO Region (RegionID, RegionName) VALUES
(1, 'Europa Occidentale'),
(2, 'America del Nord'),
(3, 'America del Sud'),
(4, 'Asia Orientale'),
(5, 'Asia del sud'),
(6, 'Europa orientale'),
(7, 'Africa Settentrionale');

INSERT INTO Country (CountryID, RegionID, CountryName, PostalCode) VALUES
(1, 1, 'Italia', '00100'),
(2, 1, 'Francia', '75000'),
(3, 1, 'Germania', '10115'),
(4, 2, 'Stati Uniti', '10001'),
(5, 2, 'Messico', '01000'),
(6, 3, 'Brasile', '20000'),
(7, 4, 'Cina', '100000'),
(8, 5, 'India', '110001'),
(9, 6, 'Russia', '101000'),
(10, 7, 'Egitto', '11311');



