USE vendita_e;
-- 1.Verificare che i campi definiti come PK siano univoci. 

SELECT toyID, COUNT(*)
FROM TOYS
GROUP BY toyID
HAVING COUNT(*) > 1;

SELECT Country.CountryID, COUNT(*)
FROM Country
GROUP BY CountryID
HAVING COUNT(*) > 1;

SELECT productcategory.ProductCategoryID, COUNT(*)
FROM productcategory
GROUP BY ProductCategoryID
HAVING COUNT(*) > 1;

SELECT products.ProductID, COUNT(*)
FROM products
GROUP BY ProductID
HAVING COUNT(*) > 1;

SELECT region.RegionID, COUNT(*)
FROM region
GROUP BY RegionID
HAVING COUNT(*) > 1;

SELECT sales.salesID, COUNT(*)
FROM sales
GROUP BY salesID
HAVING COUNT(*) > 1;


-- 2.Esporre l’elenco dei soli prodotti venduti e per ognuno di questi il fatturato totale per anno.
SELECT 
    P.ProductName,
    YEAR(S.SalesDate) AS Year,
    SUM(S.SalesTotalPrice) AS TotalRevenue
FROM 
    Sales S
JOIN 
    Products P ON S.ProductID = P.ProductID
GROUP BY 
    P.ProductName, YEAR(S.SalesDate)
ORDER BY 
    P.ProductName, YEAR(S.SalesDate);
    
-- 3.Esporre il fatturato totale per stato per anno. Ordina il risultato per data e per fatturato decrescente. 

SELECT 
    C.CountryName,
    YEAR(S.SalesDate) AS Year,
    SUM(S.SalesTotalPrice) AS TotalRevenue
FROM 
    Sales S
JOIN 
    Country C ON S.RegionID = C.RegionID
GROUP BY 
    C.CountryName, YEAR(S.SalesDate)
ORDER BY 
    YEAR(S.SalesDate) ASC, TotalRevenue DESC;


    
    

-- 4. Rispondere alla seguente domanda: qual è la categoria di articoli maggiormente richiesta dal mercato? 

SELECT 
    Prods.ProductID, ProductCategoryName,
    COUNT(*) AS TotalSales
FROM 
    (SELECT Sales.ProductID, SalesTotalPrice, SalesProductQuantity, SalesDate, SalesProductName, ProductCategoryName  FROM Sales
	JOIN ( SELECT products.ProductID, productcategoryID, ProductName, ProductPrice, ProductQuantity, ProductCategoryName FROM products
	JOIN productcategory ON products.ProductID = productcategory.ProductID) Catprod
	ON Sales.productID = Catprod.productID) AS Prods
 GROUP BY  Prods.ProductID, ProductCategoryName
ORDER BY 
    TotalSales DESC
LIMIT 1;

-- 5. Rispondere alla seguente domanda: quali sono, se ci sono, i prodotti invenduti? Proponi due approcci risolutivi differenti.

SELECT ProductID, ProductName
FROM Products
WHERE ProductID NOT IN (
    SELECT DISTINCT ProductID
    FROM Sales
);

-- 6. Esporre l’elenco dei prodotti con la rispettiva ultima data di vendita (la data di vendita più recente). 

    SELECT 
    P.ProductID,
    P.ProductName,
    MAX(S.SalesDate) AS UltimaDataDiVendita
FROM 
    Products P
LEFT JOIN 
    Sales S ON P.ProductID = S.ProductID
GROUP BY 
    P.ProductID, P.ProductName;

    
    -- BONUS:  Esporre l’elenco delle transazioni indicando nel result set il codice documento,
    -- la data, il nome del prodotto, la categoria del prodotto, il nome dello stato, il nome della regione di vendita e un campo booleano valorizzato
    -- in base alla condizione che siano passati più di 180 giorni dalla data vendita o meno (>180 -> True, <= 180 -> False)
    
    SELECT
    Sales.SalesID AS CodiceDocumento,
    Sales.SalesDate AS Data,
    Products.ProductName AS NomeProdotto,
    ProductCategory.ProductCategoryName AS CategoriaProdotto,
    region.RegionName AS NomeRegioneVendita,
    CASE WHEN DATEDIFF(CURDATE(), Sales.SalesDate) > 180 THEN TRUE ELSE FALSE END AS PassatiPiùDi180Giorni
FROM
    Sales
JOIN
    Products ON Sales.ProductID = Products.ProductID
JOIN
    ProductCategory ON Products.ProductID = ProductCategory.ProductID
JOIN
    region ON Sales.RegionID = region.RegionID
;
